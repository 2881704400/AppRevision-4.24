function sceneConfiguration() {

    // ---隐藏底部导航菜单
    $('.toolbar').css('display', 'none');

    // ---返回上一页底部导航显示
    $('.close i').click(function () {
        $('.toolbar').css('display', 'block');
    })

    // ---选择设备
    $('.xzSb').click(function() {
        $('.toolbar').css('display', 'block');
        
        // 清空毫秒数
        $('.sceneState input').val('')
    })

    // ---选择设备
    $('#sceneLists .list ul').on('click','li',function(){
        var xzsbText = $(this).text() + `<i></i>`;
        $('.xzSb').html(xzsbText)
    })



    // ---添加底部 btn
    var footBtn = `
        <div class="">
            <a href="#" class="button cancelBtn button-big button-red">取消</a>
        </div>
        <div class=" add">
            <a href="#" class="button button-big button-green addColor">添加</a>
        </div>
    `
    $('.footer').html(footBtn);

    // ---手机键盘
    var winHeight = $(window).height();   //获取当前页面高度
    $(window).resize(function () {
        var thisHeight = $(this).height();
        if (winHeight - thisHeight > 50) {
            // $("#footer").hide(0);
            $('.footer').html('');
        } else {
            $('.footer').html(footBtn);

            if($('.duration input').val() != '') {
                $('.add a').addClass('addColorOk')
            }


        }
    });

    // ---控制设备、设置延迟-切换
    $('label').click(function () {
        $(this).parent('div').addClass('check').siblings().removeClass('check');
        $(this).children('.test-radioInput').css('border', ' 1.5px solid');

        console.log($(this).find(':radio').val());
        var checkedRadio = $(this).find(':radio').val();

        if (checkedRadio == 'kz') {
            $('.select').stop().fadeIn("1");
            $('.duration').stop().fadeOut("1");
        }

        if (checkedRadio == 'sz') {

            $('.duration').stop().fadeIn("1");
            $('.select').stop().fadeOut("1");
        }

    })

    // ---添加场景
    $('.sceneState input').blur(function () {
        if ($('.xzSb').html().substring(0,14) != 'Smart elevator' && $('.duration input').val() != '') {

            $('.add a').addClass('addColorOk')



            console.log('不为空可以添加');
            $('.add').click(function(){
                console.log('设备场景控制添加成功');
            })
        } else {
            $('.add a').removeClass('addColorOk')
            console.log('请选择控制的设备');
        }
    })
    
    console.log($('.xzSb').html().substring(0,14));

}
