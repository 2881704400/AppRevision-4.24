﻿var pages = [
    {
        'name': '首页',
        'htmlName': 'index',
        'value': '1',
        'icon': 'yingsaitong'
    },
    {
        'name': '设备数据',
        'htmlName': 'RealTime',
        'value': '1',
        'icon': 'shishizhuangtai'
    },
    {
        'name': '实时快照',
        'htmlName': 'ActualSys',
        'value': '1',
        'icon': 'kuaizhao'
    },
    {
        'name': '系统配置',
        'htmlName': 'Systems',
        'value': '1',
        'icon': 'xujicanshupeizhi'
    },
    {
        'name': '事件查询',
        'htmlName': 'EvtSelect',
        'value': '1',
        'icon': 'chaxun'
    },
    {
        'name': '报警排表',
        'htmlName': 'AlarmTabulate',
        'value': '1',
        'icon': 'renyuanpaiban'
    },
    {
        'name': '定时任务',
        'htmlName': 'TimedTask',
        'value': '1',
        'icon': 'dingshirenwu'
    },
    {
        'name': '设备联动',
        'htmlName': 'EquipLink',
        'value': '1',
        'icon': 'shebeiguanli'
    },
    {
        'name': '门禁系统',
        'htmlName': 'EntrGuard',
        'value': '0',
        'icon': 'menjinxitong'
    },
    //{
    //    'name': 'U3D',
    //    'htmlName': 'U3D',
    //    'value': '1'
    //},
    {
        'name': '视频系统',
        'htmlName': 'VideoSystem',
        'value': '0',
        'icon': 'shipin'
    },
    {
        'name': '能耗系统',
        'htmlName': 'Energy',
        'value': '0',
        'icon': 'nenghaoguanli'
    },
]