﻿var perConfig = [
    {
        id: 1,
        title: '系统页面',
        page: [
            "2001,'设备数据(Web)','AlarmCenter.RealTime','1','1'",
            "2002,'实时快照(Web)','AlarmCenter.ActualSys','1','1'",
            "2003,'系统配置(Web)','AlarmCenter.Systems','1','1'",
            "2004,'事件查询(Web)','AlarmCenter.EvtSelect','1','1'",
            "2005,'报警排表(Web)','AlarmCenter.AlarmTabulate','1','1'",
            "2006,'定时任务(Web)','AlarmCenter.TimedTask','1','1'",
            "2007,'设备联动(Web)','AlarmCenter.EquipLink','1','1'",
            "2008,'实时快照(App)','AlarmCenter.App.MessageTool','1','1'",
            "2009,'设备数据(App)','AlarmCenter.App.RealTimeTool','1','1'",
            "2010,'语音控制(App)','AlarmCenter.App.VoiceTool','1','1'",
			"2011,'视频系统(App)','AlarmCenter.App.VideoTool','1','1'"
        ]
    },
    {
        id: 2,
        title: '定制页面',
        page: [
            //"2001,'今日交易(App)','AlarmCenter.App.Todays','1','1'",
            //"2002,'三十天交易(App)','AlarmCenter.App.ThirtyDays','1','1'",
            //"2003,'月度交易(App)','AlarmCenter.App.Monthly','1','1'",
            //"2004,'交易类型(App)','AlarmCenter.App.TradeTypes','1','1'",
            //"2005,'推荐排行(App)','AlarmCenter.App.RecomTop','1','1'",
            //"2006,'商户统计(App)','AlarmCenter.App.RegisterChart','1','1'",
            //"2007,'品种类型(App)','AlarmCenter.App.VarietieTypes','1','1'",
            //"2008,'货量统计(App)','AlarmCenter.App.CargoStatistics','1','1'",
            //"2009,'货物流向统计(App)','AlarmCenter.App.FlowStatistics','1','1'",
            //"2010,'头寸统计(App)','AlarmCenter.App.PositionStatistics','1','1'",
            //"2011,'头寸分布(App)','AlarmCenter.App.PositionDist','1','1'",
            //"2012,'物流任务统计(App)','AlarmCenter.App.ActivityStat','1','1'",
            //"2013,'船舶及监装分布(App)','AlarmCenter.App.ActivityDynamic','1','1'"
        ]
    }
]